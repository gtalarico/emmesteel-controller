from setuptools import setup
from setuptools import setup, find_packages


setup(
    name='emmesteel',
    version='0.0.2',    
    description='Emmesteel',
    url='https://github.com/gtalarico/emmesteel',
    author='Gui Talarico',
    author_email='gtalarico.dev@gmail.com',
    license='BSD 2-clause',
    packages=find_packages(),
    install_requires=['websockets>=13.0.0'],

    classifiers=[
        'Development Status :: 1 - Planning',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: BSD License',  
        'Operating System :: POSIX :: Linux',        
        'Programming Language :: Python :: 3.8',
    ],
)
